//Desafío de las cajas//
//Cambiar el titulo .getElementById//

//Desafío de las cajas//
//Cambiar el titulo .getElementById//

document.getElementById("btn-titulo").addEventListener("click", () => {
  const titulo = document.getElementById("titulo");
  titulo.textContent = "¡Danny Villalobos!";
});


//cambiar color de las cajas//

document.getElementById("btn-cajas").addEventListener("click", () =>
 {
  const cajas = 
        document.getElementsByClassName("caja");
  for (let i = 0; i < cajas.length; i++) {
    cajas[i].style.backgroundColor = "#F8BBD0"; // rosa clarito
  }
});

//Usar querySelector para solo cambiar el color de la primera caja//

document.getElementById("btn-primera").addEventListener("click",()=>
{
  const primeracaja =document.querySelector(".caja");

  primeracaja.style.backgroundColor = "#ADD8E6";
  
});

//Cambiarle el borde a todas las cajas//

document.getElementById("btn-bordes").addEventListener("click", () => {
  const cajas = document.querySelectorAll(".caja");
  cajas.forEach(caja => {
    caja.style.border = "2px solid #FF69B4"; // rosa un poco más fuerte
  });
});
